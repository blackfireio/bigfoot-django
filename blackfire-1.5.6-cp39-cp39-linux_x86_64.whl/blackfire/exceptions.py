class BlackfireApiException(Exception):
    pass


class BlackfireProfilerException(Exception):
    pass


class BlackfireAPMException(Exception):
    pass
